# PingPont 

* v1: la básica, con handleInput(SDL_Event)
* v2: como v1 pero usa el Input Handler
* v3: como v2 pero con más tipos de paddles y balls
* v4: usa el primer diseño de componentes
* v5: usa factorías


## Como usar

Copiar la carpeta **game** y **main.cpp** a la raíz de la carpeta **src**. La estructura de **src** queda así:

     src/game
     src/utils
     src/json
     src/sdlutils
     main.cpp

